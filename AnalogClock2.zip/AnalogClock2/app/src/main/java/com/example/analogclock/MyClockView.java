package com.example.analogclock;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;


public class MyClockView extends View {
    private final Handler handler;
    private Context context;
    private long elapsedTime;
    private State state;
    private Paint paint;
    private Drawer draw;
    private Thread timerThread;
    private Runnable refreshRunnable;
    private ImageView imageObject;
    private  long radius;

static class State{
        private long startTime;
        private long cummulatedTime;
        private long elapsedTime;
        //time units
        public long seconds;
        public long minutes;
        public long hours;

        public long getStartTime() {
            return startTime;
        }

        public void setStartTime(long startTime) {
            this.startTime = startTime;
        }

        public long getCummulatedTime() {
            return cummulatedTime;
        }

        public void setCummulatedTime(long cummulatedTime) {
            this.cummulatedTime = cummulatedTime;
        }

        public long getElapsedTime(){
            long time=startTime>0?(System.nanoTime()-startTime):0;
            elapsedTime = time+cummulatedTime;
            return elapsedTime;
        }

        public void setElapsedTime(long elapsedTime) {
            this.elapsedTime = elapsedTime;
        }

        public long getHours() {
            return hours;
        }

        public void setHours(long hours) {
            this.hours = hours;
        }

        public long getMinutes() {
            return minutes;
        }

        public void setMinutes(long minutes) {
            this.minutes = minutes;
        }

        public long getSeconds() {
            return seconds;
        }

        public void setSeconds(long seconds) {
            this.seconds = seconds;
        }
    }


    public MyClockView(Context ctx,ImageView img){
         super(ctx);
         this.context= ctx;
         state = new State();
         paint = new Paint();
         draw= new Drawer();
         draw.setPaint(paint);
         handler = new Handler(context.getMainLooper());

        //imageObject = (ImageView) findViewById(R.id.clockbg);
        setImageObject(img);
        radius = (imageObject.getWidth()/2)-draw.getMargin();
        runnableInitialisation();
}

    public void formatTime(long time){
       // long tempSec = time / (1000 * 1000 * 1000);
        //long sec = tempSec % 60;
         //long min = (tempSec / 60) % 60;
          //long hour = (tempSec / (60 * 60)) % 24;
        long seconds = (time/ (1000*1000*1000))%60;
        long minutes = seconds %60;
        long hours = minutes%60;
        state.setSeconds(seconds);
        state.setMinutes(minutes);
        state.setHours(hours);
        Log.w("Time",state.getHours()+":"+state.getMinutes()+":"+state.getSeconds());
    }


    public ImageView getImageObject() {
        return imageObject;
    }

    public void setImageObject(ImageView imageObject) {
        this.imageObject = imageObject;
    }

    @Override
    public Handler getHandler() {
        return handler;
    }

    public Runnable getRefreshRunnable() {
        return refreshRunnable;
    }

    public void setRefreshRunnable(Runnable refreshRunnable) {
        this.refreshRunnable = refreshRunnable;
    }

    public void startChrono() {

        state.setStartTime(System.nanoTime());
        updateChronoOnUiThreadMethod();
    }

    public void refreshChrono() {
        formatTime(state.getElapsedTime());
        //state.getSec eTc...
    }


    public void stopChrono(){
    handler.removeCallbacks(getRefreshRunnable());
    }
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //draw oval
        draw.getPaint().setColor(Color.WHITE);
        draw.drawOval(canvas,imageObject);
        //draw lines
        double angle;
        int posXline,posYline;
         angle = Math.toRadians((15-state.getSeconds())*6);
         posXline = (int) (Math.cos(angle)*imageObject.getWidth()-draw.getMargin());
        posYline = (int) Math.sin(angle)* imageObject.getHeight()-draw.getMargin();
        //draw line start point is (O,O) according to image scale
        draw.getPaint().setColor(Color.RED);
        draw.drawLine(canvas,imageObject,imageObject.getWidth()/2,imageObject.getHeight()/2,imageObject.getWidth()/2,imageObject.getHeight());
        canvas.save();

    }


    public void start() {
        startChrono();
    }





    public void runnableInitialisation() {
        refreshRunnable = new Runnable() {
            @Override
            public void run() {
                try {
                    while (!Thread.interrupted()) {
                        refreshChrono();
                        }
                        try {
                            Thread.sleep(500);

                        } catch (InterruptedException e) {

                        }

                } catch (Exception e) {
                }
            }
        };
        setRefreshRunnable(refreshRunnable);

    }
    public void updateChronoOnUiThreadMethod() {
        handler.postDelayed(getRefreshRunnable(),1000);

    }


}


